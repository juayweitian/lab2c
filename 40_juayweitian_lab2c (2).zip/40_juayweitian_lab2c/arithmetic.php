<?php

$addition = 2 + 4;
$subtraction = 6 - 2;
$multiplication = 5 * 3;
$division = 15 / 3;
$modulus = 5 % 2;

echo "Perform addition: 2 + 4 = ".$addition."<br>";
echo "Perform subtraction: 6 - 2 =".$subtraction."<br>";
echo "Perform multiplication: 5 * 3 =".$multiplication."<br>";
echo "Perform division: 15 / 3 = ".$division."<br>";
echo "Perform modulus: 5 % 2 =" .$modulus
?>